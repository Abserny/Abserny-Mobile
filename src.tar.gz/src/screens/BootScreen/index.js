/**
 * src/screens/BootScreen/index.js
 *
 * Animated launch screen — plays once when the app cold-starts.
 * Inspired by Discord's community server discovery animation:
 *   - Flowing gradient orbs that drift and pulse
 *   - Floating particle field
 *   - Logo reveal with spring bounce
 *   - Wordmark fade + letter-spacing expand
 *   - Tagline slide up
 *   - Whole screen fades out smoothly into the real app
 *
 * HOW IT WORKS:
 *   App.js renders <BootScreen onDone={...} /> while AsyncStorage is loading.
 *   BootScreen calls onDone() after ~2.8s, App.js then renders the real screen.
 *   expo-splash-screen is hidden right when BootScreen mounts so the
 *   static splash transitions seamlessly into this animated version.
 *
 * PERFORMANCE:
 *   All animations use useNativeDriver: true (opacity + transform only).
 *   The gradient orbs are plain <View>s with borderRadius — no SVG,
 *   no Skia, no extra deps. Works in both Expo Go and dev builds.
 */

import React, { useRef, useEffect } from 'react';
import {
    View, Text, Image, Animated, Easing,
    StyleSheet, Dimensions, StatusBar,
} from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { BG, CYAN, GREEN, PURPLE, AMBER } from '../../constants/colors';

const { width: W, height: H } = Dimensions.get('window');

// ── Timing constants ──────────────────────────────────────────────────────────
const T_LOGO_IN       = 700;   // logo bounce start → end
const T_WORD_IN       = 500;   // wordmark fade in
const T_TAG_IN        = 400;   // tagline slide in
const T_HOLD          = 600;   // hold everything visible
const T_FADE_OUT      = 500;   // whole screen fades to black

const TOTAL_DURATION  =
    200           +   // initial orb settle
    T_LOGO_IN     +
    120           +   // gap before wordmark
    T_WORD_IN     +
    80            +   // gap before tagline
    T_TAG_IN      +
    T_HOLD        +
    T_FADE_OUT;       // ≈ 2870ms total

// ── Gradient orb — drifting colored blob ─────────────────────────────────────
function GradientOrb({ size, color, initialX, initialY, driftX, driftY, delay, duration, opacity }) {
    const x = useRef(new Animated.Value(0)).current;
    const y = useRef(new Animated.Value(0)).current;
    const sc = useRef(new Animated.Value(0.8)).current;

    useEffect(() => {
        // Drift loop — slow sinusoidal movement
        const loopXY = Animated.loop(
            Animated.sequence([
                Animated.parallel([
                    Animated.timing(x, { toValue: driftX,  duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
                    Animated.timing(y, { toValue: driftY,  duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
                    Animated.timing(sc, { toValue: 1.15, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
                ]),
                Animated.parallel([
                    Animated.timing(x, { toValue: 0,    duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
                    Animated.timing(y, { toValue: 0,    duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
                    Animated.timing(sc, { toValue: 0.8, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
                ]),
            ])
        );
        const t = setTimeout(() => loopXY.start(), delay);
        return () => { clearTimeout(t); loopXY.stop(); };
    }, []); // eslint-disable-line

    return (
        <Animated.View style={{
            position: 'absolute',
            left: initialX - size / 2,
            top:  initialY - size / 2,
            width: size, height: size, borderRadius: size / 2,
            backgroundColor: color,
            opacity,
            transform: [{ translateX: x }, { translateY: y }, { scale: sc }],
        }} />
    );
}

// ── Floating particle ─────────────────────────────────────────────────────────
function Particle({ x, y, size, opacity, driftY, duration, delay }) {
    const ty  = useRef(new Animated.Value(0)).current;
    const op  = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        const loop = Animated.loop(
            Animated.sequence([
                Animated.delay(delay),
                Animated.parallel([
                    Animated.timing(ty, { toValue: driftY, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
                    Animated.sequence([
                        Animated.timing(op, { toValue: opacity, duration: duration * 0.3, useNativeDriver: true }),
                        Animated.timing(op, { toValue: opacity * 0.2, duration: duration * 0.7, useNativeDriver: true }),
                    ]),
                ]),
                Animated.parallel([
                    Animated.timing(ty, { toValue: 0, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
                    Animated.sequence([
                        Animated.timing(op, { toValue: opacity, duration: duration * 0.3, useNativeDriver: true }),
                        Animated.timing(op, { toValue: opacity * 0.2, duration: duration * 0.7, useNativeDriver: true }),
                    ]),
                ]),
            ])
        );
        loop.start();
        return () => loop.stop();
    }, []); // eslint-disable-line

    return (
        <Animated.View style={{
            position: 'absolute',
            left: x, top: y,
            width: size, height: size, borderRadius: size / 2,
            backgroundColor: '#ffffff',
            opacity: op,
            transform: [{ translateY: ty }],
        }} />
    );
}

// ── Seeded particle positions — deterministic, no random on render ───────────
const PARTICLES = [
    { x: W*0.08, y: H*0.15, size: 1.5, opacity: 0.35, driftY: -18, duration: 3200, delay: 0    },
    { x: W*0.22, y: H*0.28, size: 1.0, opacity: 0.20, driftY: -12, duration: 4100, delay: 400  },
    { x: W*0.38, y: H*0.12, size: 2.0, opacity: 0.28, driftY: -22, duration: 3600, delay: 200  },
    { x: W*0.55, y: H*0.20, size: 1.2, opacity: 0.18, driftY: -15, duration: 4800, delay: 700  },
    { x: W*0.70, y: H*0.10, size: 1.8, opacity: 0.30, driftY: -20, duration: 3300, delay: 100  },
    { x: W*0.85, y: H*0.25, size: 1.0, opacity: 0.22, driftY: -10, duration: 4400, delay: 550  },
    { x: W*0.15, y: H*0.45, size: 1.3, opacity: 0.16, driftY: -14, duration: 5000, delay: 300  },
    { x: W*0.48, y: H*0.38, size: 1.0, opacity: 0.20, driftY: -11, duration: 4200, delay: 900  },
    { x: W*0.78, y: H*0.42, size: 1.6, opacity: 0.25, driftY: -18, duration: 3800, delay: 150  },
    { x: W*0.92, y: H*0.55, size: 1.2, opacity: 0.18, driftY: -13, duration: 4600, delay: 650  },
    { x: W*0.05, y: H*0.65, size: 1.8, opacity: 0.22, driftY: -16, duration: 3500, delay: 450  },
    { x: W*0.33, y: H*0.72, size: 1.0, opacity: 0.15, driftY: -9,  duration: 5200, delay: 800  },
    { x: W*0.60, y: H*0.68, size: 1.4, opacity: 0.20, driftY: -14, duration: 4000, delay: 250  },
    { x: W*0.88, y: H*0.75, size: 1.6, opacity: 0.28, driftY: -19, duration: 3700, delay: 600  },
    { x: W*0.25, y: H*0.85, size: 1.2, opacity: 0.18, driftY: -12, duration: 4500, delay: 350  },
    { x: W*0.68, y: H*0.88, size: 1.0, opacity: 0.15, driftY: -10, duration: 5100, delay: 750  },
];

// ── Main component ────────────────────────────────────────────────────────────
export default function BootScreen({ onDone }) {

    // Logo
    const logoScale   = useRef(new Animated.Value(0.3)).current;
    const logoOpacity = useRef(new Animated.Value(0)).current;
    const logoY       = useRef(new Animated.Value(30)).current;

    // Wordmark
    const wordOpacity = useRef(new Animated.Value(0)).current;
    const wordY       = useRef(new Animated.Value(14)).current;

    // Tagline
    const tagOpacity  = useRef(new Animated.Value(0)).current;
    const tagY        = useRef(new Animated.Value(10)).current;

    // Whole-screen fade out
    const screenOp    = useRef(new Animated.Value(1)).current;

    useEffect(() => {
        // Hide the static expo splash — our animation takes over
        SplashScreen.hideAsync();

        const seq = Animated.sequence([
            // 1. Logo bounces in
            Animated.delay(200),
            Animated.parallel([
                Animated.spring(logoScale, {
                    toValue: 1, tension: 160, friction: 8, useNativeDriver: true,
                }),
                Animated.timing(logoOpacity, {
                    toValue: 1, duration: 280, useNativeDriver: true,
                }),
                Animated.spring(logoY, {
                    toValue: 0, tension: 160, friction: 8, useNativeDriver: true,
                }),
            ]),

            // 2. Wordmark fades + slides in
            Animated.delay(120),
            Animated.parallel([
                Animated.timing(wordOpacity, {
                    toValue: 1, duration: T_WORD_IN,
                    easing: Easing.out(Easing.cubic), useNativeDriver: true,
                }),
                Animated.spring(wordY, {
                    toValue: 0, tension: 200, friction: 12, useNativeDriver: true,
                }),
            ]),

            // 3. Tagline slides up
            Animated.delay(80),
            Animated.parallel([
                Animated.timing(tagOpacity, {
                    toValue: 1, duration: T_TAG_IN,
                    easing: Easing.out(Easing.cubic), useNativeDriver: true,
                }),
                Animated.spring(tagY, {
                    toValue: 0, tension: 200, friction: 12, useNativeDriver: true,
                }),
            ]),

            // 4. Hold
            Animated.delay(T_HOLD),

            // 5. Fade entire screen to black then call onDone
            Animated.timing(screenOp, {
                toValue: 0, duration: T_FADE_OUT,
                easing: Easing.in(Easing.cubic), useNativeDriver: true,
            }),
        ]);

        seq.start(() => onDone?.());
        return () => seq.stop();
    }, []); // eslint-disable-line

    return (
        <Animated.View style={[styles.root, { opacity: screenOp }]}>
            <StatusBar hidden />

            {/* ── Gradient orbs — background atmosphere ── */}
            {/* Top-left: cyan */}
            <GradientOrb
                size={W * 0.85} color={CYAN + '18'}
                initialX={W * 0.05} initialY={H * 0.12}
                driftX={30} driftY={20}
                delay={0} duration={5000} opacity={1}
            />
            {/* Top-right: purple */}
            <GradientOrb
                size={W * 0.75} color={PURPLE + '22'}
                initialX={W * 0.95} initialY={H * 0.08}
                driftX={-25} driftY={30}
                delay={300} duration={6000} opacity={1}
            />
            {/* Center: green — slowest, largest */}
            <GradientOrb
                size={W * 1.1} color={GREEN + '12'}
                initialX={W * 0.50} initialY={H * 0.50}
                driftX={20} driftY={-25}
                delay={600} duration={7500} opacity={1}
            />
            {/* Bottom-left: amber */}
            <GradientOrb
                size={W * 0.65} color={AMBER + '15'}
                initialX={W * 0.10} initialY={H * 0.85}
                driftX={35} driftY={-20}
                delay={150} duration={5500} opacity={1}
            />
            {/* Bottom-right: cyan */}
            <GradientOrb
                size={W * 0.70} color={CYAN + '10'}
                initialX={W * 0.92} initialY={H * 0.80}
                driftX={-30} driftY={-15}
                delay={450} duration={6500} opacity={1}
            />

            {/* ── Particles ── */}
            {PARTICLES.map((p, i) => <Particle key={i} {...p} />)}

            {/* ── Center content ── */}
            <View style={styles.center}>

                {/* Logo image */}
                <Animated.View style={{
                    opacity: logoOpacity,
                    transform: [{ scale: logoScale }, { translateY: logoY }],
                    marginBottom: 28,
                }}>
                    {/* Eye icon — replace with your actual logo asset */}
                    <View style={styles.logoCircle}>
                        <View style={styles.eyeOuter}>
                            <View style={styles.eyeInner} />
                            <View style={styles.eyeGlint} />
                        </View>
                    </View>
                </Animated.View>

                {/* Wordmark */}
                <Animated.Text style={[
                    styles.wordmark,
                    { opacity: wordOpacity, transform: [{ translateY: wordY }] },
                ]}>
                    ABSERNY
                </Animated.Text>

                {/* Tagline */}
                <Animated.Text style={[
                    styles.tagline,
                    { opacity: tagOpacity, transform: [{ translateY: tagY }] },
                ]}>
                    see the world
                </Animated.Text>

            </View>

            {/* Bottom edge glow line */}
            <Animated.View style={[styles.bottomGlow, { opacity: wordOpacity }]} />
        </Animated.View>
    );
}

const styles = StyleSheet.create({
    root: {
        flex: 1,
        backgroundColor: BG,
        overflow: 'hidden',
    },
    center: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },

    // Logo circle — a stylised eye
    logoCircle: {
        width: 88, height: 88, borderRadius: 44,
        backgroundColor: 'rgba(255,255,255,0.04)',
        borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)',
        alignItems: 'center', justifyContent: 'center',
        // Soft glow behind it
        shadowColor: CYAN,
        shadowOffset: { width: 0, height: 0 },
        shadowOpacity: 0.5, shadowRadius: 30,
        elevation: 12,
    },
    eyeOuter: {
        width: 44, height: 28,
        borderRadius: 14,
        borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.55)',
        alignItems: 'center', justifyContent: 'center',
        overflow: 'visible',
    },
    eyeInner: {
        width: 14, height: 14, borderRadius: 7,
        backgroundColor: 'rgba(255,255,255,0.85)',
    },
    eyeGlint: {
        position: 'absolute', top: 4, right: 10,
        width: 4, height: 4, borderRadius: 2,
        backgroundColor: 'rgba(255,255,255,0.5)',
    },

    wordmark: {
        fontSize: 22, fontWeight: '300',
        letterSpacing: 10,
        color: 'rgba(255,255,255,0.92)',
        marginBottom: 10,
    },
    tagline: {
        fontSize: 12,
        letterSpacing: 4,
        color: 'rgba(255,255,255,0.28)',
        fontWeight: '400',
    },

    // Thin horizontal glow line at the very bottom
    bottomGlow: {
        position: 'absolute', bottom: 0, left: '15%', right: '15%',
        height: 1,
        backgroundColor: CYAN,
        shadowColor: CYAN,
        shadowOffset: { width: 0, height: 0 },
        shadowOpacity: 0.8, shadowRadius: 8,
    },
});
