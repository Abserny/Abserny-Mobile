/**
 * screens/MainScreen/ModeBanner.js
 * Enhanced — mode chip glows with its accent color via shadowColor.
 * Active dot morphs width with spring. Pure display.
 */

import React, { useRef, useEffect } from 'react';
import { View, Text, Animated, Easing } from 'react-native';
import { MODES } from '../../constants/modes';
import { MODE_COLORS, GREEN, ON_SURFACE_LOW } from '../../constants/colors';
import { MODE_ICONS } from '../../components/icons';
import { s } from './styles';

// Dot that morphs width smoothly when it becomes active
function MorphDot({ active, color }) {
    const width = useRef(new Animated.Value(active ? 14 : 4)).current;

    useEffect(() => {
        Animated.spring(width, {
            toValue: active ? 14 : 4,
            tension: 260, friction: 14,
            useNativeDriver: false, // width is not supported by native driver
        }).start();
    }, [active]); // eslint-disable-line

    return (
        <Animated.View style={[
            s.modeDot,
            { width, backgroundColor: active ? color : ON_SURFACE_LOW },
        ]} />
    );
}

export function ModeBanner({ modeIndex, modeAnim, watching, modeStrings, isRTL }) {
    const activeColor = watching ? GREEN : MODE_COLORS[MODES[modeIndex].id];

    return (
        <Animated.View style={[
            s.modeBanner,
            { transform: [{ translateY: modeAnim }] },
            isRTL && s.rowReverse,
        ]}>
            {MODES.map((mode, i) => {
                if (i !== modeIndex) return null;
                const ModeIcon = MODE_ICONS[mode.id];
                const color    = watching ? GREEN : MODE_COLORS[mode.id];
                return (
                    <View key={mode.id} style={[
                        s.activeModeChip,
                        {
                            backgroundColor: color + '18',
                            borderColor:     color + '40',
                            shadowColor:     color,
                        },
                    ]}>
                        {ModeIcon && <ModeIcon size={14} color={color} />}
                        <Text style={[s.activeModeText, { color }]}>
                            {watching
                                ? (isRTL ? 'مراقبة' : 'WATCH')
                                : modeStrings[mode.id]?.label?.toUpperCase()
                            }
                        </Text>
                    </View>
                );
            })}

            <View style={s.modeDots}>
                {MODES.map((mode, i) => {
                    const color = watching ? GREEN : MODE_COLORS[mode.id];
                    return (
                        <MorphDot key={mode.id} active={i === modeIndex} color={color} />
                    );
                })}
            </View>
        </Animated.View>
    );
}
