/**
 * components/primitives/WaveBar.js
 * Speaking wave bar — smoother cubic easing, slightly taller.
 * Drop-in replacement: same props { color, delay }.
 */

import React, { useRef, useEffect } from 'react';
import { Animated, Easing } from 'react-native';

export function WaveBar({ color, delay = 0 }) {
    const scaleY  = useRef(new Animated.Value(0.12)).current;
    const opacity = useRef(new Animated.Value(0.7)).current;

    useEffect(() => {
        const loop = Animated.loop(
            Animated.sequence([
                Animated.delay(delay),
                Animated.parallel([
                    Animated.timing(scaleY,  { toValue: 1,    duration: 300, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
                    Animated.timing(opacity, { toValue: 1,    duration: 300, useNativeDriver: true }),
                ]),
                Animated.parallel([
                    Animated.timing(scaleY,  { toValue: 0.12, duration: 300, easing: Easing.in(Easing.cubic),  useNativeDriver: true }),
                    Animated.timing(opacity, { toValue: 0.5,  duration: 300, useNativeDriver: true }),
                ]),
            ]),
        );
        loop.start();
        return () => loop.stop();
    }, []); // eslint-disable-line

    return (
        <Animated.View style={{
            width: 3.5, height: 32, borderRadius: 2,
            backgroundColor: color,
            transform: [{ scaleY }],
            opacity,
        }} />
    );
}
