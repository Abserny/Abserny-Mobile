/**
 * components/primitives/LiveDot.js
 * Blinking dot with a ripple ring behind it — more alive than a simple blink.
 * Drop-in replacement: same props { color }.
 */

import React, { useRef, useEffect } from 'react';
import { Animated, View } from 'react-native';

export function LiveDot({ color }) {
    const op     = useRef(new Animated.Value(1)).current;
    const ripple = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        const blink = Animated.loop(Animated.sequence([
            Animated.timing(op,     { toValue: 0.15, duration: 700, useNativeDriver: true }),
            Animated.timing(op,     { toValue: 1.0,  duration: 700, useNativeDriver: true }),
        ]));
        const rippleLoop = Animated.loop(Animated.sequence([
            Animated.timing(ripple, { toValue: 1,    duration: 1200, useNativeDriver: true }),
            Animated.timing(ripple, { toValue: 0,    duration: 0,    useNativeDriver: true }),
        ]));
        blink.start(); rippleLoop.start();
        return () => { blink.stop(); rippleLoop.stop(); };
    }, []); // eslint-disable-line

    const rippleScale   = ripple.interpolate({ inputRange: [0, 1], outputRange: [1, 2.8] });
    const rippleOpacity = ripple.interpolate({ inputRange: [0, 0.3, 1], outputRange: [0, 0.4, 0] });

    return (
        <View style={{ width: 14, height: 14, alignItems: 'center', justifyContent: 'center' }}>
            <Animated.View style={{
                position: 'absolute',
                width: 5, height: 5, borderRadius: 2.5,
                backgroundColor: color,
                opacity: rippleOpacity,
                transform: [{ scale: rippleScale }],
            }} />
            <Animated.View style={{
                width: 5, height: 5, borderRadius: 2.5,
                backgroundColor: color,
                opacity: op,
            }} />
        </View>
    );
}
