/**
 * components/primitives/ScanRing.js
 * Dual-arc scanning ring — outer slow + inner fast, creates depth.
 * Drop-in replacement: same props { color }.
 */

import React, { useRef, useEffect } from 'react';
import { Animated, View } from 'react-native';

export function ScanRing({ color }) {
    const rot1 = useRef(new Animated.Value(0)).current;
    const rot2 = useRef(new Animated.Value(0)).current;
    const pulse = useRef(new Animated.Value(0.6)).current;

    useEffect(() => {
        const loop1 = Animated.loop(
            Animated.timing(rot1, { toValue: 1, duration: 1800, useNativeDriver: true }),
        );
        const loop2 = Animated.loop(
            Animated.timing(rot2, { toValue: -1, duration: 900, useNativeDriver: true }),
        );
        const loopP = Animated.loop(Animated.sequence([
            Animated.timing(pulse, { toValue: 1,   duration: 500, useNativeDriver: true }),
            Animated.timing(pulse, { toValue: 0.4, duration: 500, useNativeDriver: true }),
        ]));
        loop1.start(); loop2.start(); loopP.start();
        return () => { loop1.stop(); loop2.stop(); loopP.stop(); };
    }, []); // eslint-disable-line

    const r1 = rot1.interpolate({ inputRange: [0, 1],  outputRange: ['0deg',    '360deg'] });
    const r2 = rot2.interpolate({ inputRange: [-1, 0], outputRange: ['-360deg', '0deg']   });

    return (
        <View style={{ width: 72, height: 72, alignItems: 'center', justifyContent: 'center' }}>
            <Animated.View style={{
                position: 'absolute',
                width: 72, height: 72, borderRadius: 36,
                borderWidth: 1.5,
                borderColor: 'transparent',
                borderTopColor: color,
                borderRightColor: color + '40',
                transform: [{ rotate: r1 }],
            }} />
            <Animated.View style={{
                position: 'absolute',
                width: 46, height: 46, borderRadius: 23,
                borderWidth: 1,
                borderColor: 'transparent',
                borderTopColor: color + 'CC',
                borderLeftColor: color + '30',
                transform: [{ rotate: r2 }],
            }} />
            <Animated.View style={{
                width: 6, height: 6, borderRadius: 3,
                backgroundColor: color,
                opacity: pulse,
            }} />
        </View>
    );
}
